define({
    a:123
});