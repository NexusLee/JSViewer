{
	panelTitle0: "Bookmarks",
	panelTitle1: "Add Bookmarks",
	
	btnAdd: "Add Bookmark",
	msgAdd: "Add current extent as bookmark named"
}
