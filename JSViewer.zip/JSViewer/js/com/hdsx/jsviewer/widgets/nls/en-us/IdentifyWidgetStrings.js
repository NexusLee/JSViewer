/**
 * @author sbiickert
 */
{
	btnIdentify: "Identify",
	
	panelTitle0: "Identify",
	panelTitle1: "Results",
	
	msgReady: "Ready",
	msgIdentify: "Identifying...",
	msgFound: "${0} feature(s) found."

}
