/**
 * @author sbiickert
 */
{
	msgLoad: "Getting feed...",
	msgReady: "Ready.",
	msgFound: "${0} result(s) found."
}
