/**
 * @author sbiickert
 * French Bundle - Done by Eric Gosselin
 */
{
	defaultProjectionName: "Projection de la carte",
	
	panelTitle0: "Par adresse",
	panelTitle1: "Par coordonn&eacute;es",
	panelTitle2: "R&eacute;sultats",
	
	promptX: "Longitude (X)",
	promptY: "Latitude (Y)",
	promptSR: "Projection",
	promptEx: "Exemple",
	
	btnLocate: "Trouver",
	btnClear: "Effacer",
	
	msgLocate: "Veuillez patienter...",
	msgReady: "Pr&ecirc;t.",
	msgFound: "${0} endroit(s) trouv&eacute;",
	
	resultTitle: "Coordonn&eacute;es",
	resultScore: "Marque"
}
