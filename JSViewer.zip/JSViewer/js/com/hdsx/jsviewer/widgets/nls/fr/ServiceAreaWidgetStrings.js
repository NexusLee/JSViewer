/**
 * @author sbiickert
 * French Bundle - Done by Eric Gosselin
 */
{
	msgServiceArea: "Utiliser la souris pour d&eacute;finir un emplacement",	
	msgKnownLocations: "Ou choisir un emplacement identifi&eacute; par les autres outils",
	promptInterval: "Temps de conduite (min)",
	
	btnSubmit: "Voir l'aire de service"
}
