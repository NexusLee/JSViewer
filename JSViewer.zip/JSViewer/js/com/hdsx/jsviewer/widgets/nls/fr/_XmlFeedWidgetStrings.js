/**
 * @author sbiickert
 */
{
	msgLoad: "Chargement du Fil...",
	msgReady: "Pr&ecirc;t.",
	msgFound: "${0} r&eacute;sultat(s) trouv&eacute;(s)"
}

