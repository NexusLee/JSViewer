/**
 * @author sbiickert
 * French Bundle - Done by Eric Gosselin
 */
{
	btnIdentify: "Identification",
	
	panelTitle0: "Identification",
	panelTitle1: "R&eacute;sultats",
	
	msgReady: "Pr&ecirc;t",
	msgIdentify: "Identification...",
	msgFound: "${0} &eacute;l&eacute;ment(s) trouv&eacute;(s)."

}
