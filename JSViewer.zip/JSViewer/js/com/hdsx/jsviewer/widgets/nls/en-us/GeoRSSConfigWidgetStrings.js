/**
 * @author sbiickert
 */
{
	panelTitle0: "Enter URL",
	panelTitle1: "Results",
	
	promptUrl: "GeoRSS URL",
	
	btnGet: "Get Feed",
	btnClear: "Clear",
	
	msgLoad: "Getting feed...",
	msgReady: "Ready.",
	msgFound: "${0} result(s) found."
}
