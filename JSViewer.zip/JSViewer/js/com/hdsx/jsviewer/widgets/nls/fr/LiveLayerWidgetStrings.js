/**
 * @author sbiickert
 * French Bundle - Done by Eric Gosselin
 */
{
	msgLoad: "Chargement...",
	msgReady: "Pr&ecirc;t.",
	msgFound: "${0} r&eacute;sultat(s) trouv&eacute;."
}
