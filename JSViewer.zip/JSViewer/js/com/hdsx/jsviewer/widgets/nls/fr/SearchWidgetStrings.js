/**
 * @author sbiickert
 * French Bundle - Done by Eric Gosselin
 */
{
	panelTitle0: "Par g&eacute;ometrie",
	panelTitle1: "Par texte",
	panelTitle2: "R&eacute;sultats",
	
	promptSearchLayer: "Couche de recherche",
	promptTextSearch: "Recherche ${0} par ${1}  [Exemple: ${2}]",
	promptGraphicSearch: "Utiliser les outils de recherche graphique pour s&eacute;lectionner ${0}",
	
	msgSearchPoint: "Recherche par point",
	msgSearchLine: "Recherche par ligne",
	msgSearchRect: "Recherche par rectangle",
	msgSearchPolygon: "Recherche par polygone",
	msgSearchClear: "Effacer r&eacute;sultats de recherche",
	
	btnSearch: "Recherche",
	btnClear: "Effacer",
	
	msgReady: "Pr&ecirc;t.",
	msgSearch: "Recherche...",
	msgFound: "${0} entit&eacute;(s) trouv&eacute;."

}
