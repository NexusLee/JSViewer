/**
 * @author sbiickert
 * French Bundle - Done by Eric Gosselin
 */
{
	panelTitle0: "Signets",
	panelTitle1: "Ajout de signets",
	
	btnAdd: "Ajouter un signet",
	msgAdd: "AJouter l'&eacute;tendue courante comme signet"
}
