/**
 * @author sbiickert
 */
{
	msgServiceArea: "Use the mouse to define a location",	
	msgKnownLocations: "Or choose a location identified by other tools",
	promptInterval: "Drive Times (min)",
	
	btnSubmit: "Show Service Area"
}
