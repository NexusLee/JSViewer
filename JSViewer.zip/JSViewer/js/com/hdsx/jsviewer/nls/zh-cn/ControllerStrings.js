/**
 * @author sbiickert
 */
define({
    msgCurrentTool: "当前操作: ${0}"
});