/**
 * @author sbiickert
 */
define({
    navPanTool: "平移",
    navZoomInTool: "放大",
    navZoomOutTool: "缩小"
});

