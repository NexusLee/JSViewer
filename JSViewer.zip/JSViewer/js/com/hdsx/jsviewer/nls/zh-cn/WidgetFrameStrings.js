/**
 * @author sbiickert
 */
define({
    minimize: "最小化",
    close: "关闭"
});