/**
 * @author sbiickert
 */
define({
    root: (
    {
        navPanTool: "Pan",
        navZoomInTool: "Zoom In",
        navZoomOutTool: "Zoom Out"
    }),
    'zh-cn': true
});

