/**
 * @author sbiickert
 */
define({
    root: (
    {
        msgCurrentTool: "Current Action: ${0}"
    }),
    'zh-cn': true
});