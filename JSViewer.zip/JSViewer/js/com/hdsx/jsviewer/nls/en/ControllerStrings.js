/**
 * @author sbiickert
 */
define({
	msgCurrentTool: "Current Action: ${0}"
});
