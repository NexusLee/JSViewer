/**
 * @author sbiickert
 * French Bundle - Done by Eric Gosselin
 */
{
	minimize: "Minimiser",
	close: "Fermer"
}
