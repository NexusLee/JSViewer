/**
 * @author sbiickert
 * French Bundle - Done by Eric Gosselin
 */
{
	msgCurrentTool: "Mode carte: ${0}"
}
