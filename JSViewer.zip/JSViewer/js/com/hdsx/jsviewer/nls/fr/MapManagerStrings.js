/**
 * @author sbiickert
 * French Bundle - Done by Eric Gosselin
 */
{
	navPanTool: "Pan",
	navZoomInTool: "Zoom avant",
	navZoomOutTool: "Zoom arri&egrave;re"
}
