/**
 * @author sbiickert
 */
define({
    minimize: "Minimize",
    close: "Close"
});