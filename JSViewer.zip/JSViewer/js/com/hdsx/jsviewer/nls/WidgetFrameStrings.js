/**
 * @author sbiickert
 */
define({
    root: (
    {
        minimize: "Minimize",
        close: "Close"
    }),
    'zh-cn': true
});