/**
 * @author sbiickert
 */
{
	msgCurrentTool: "Current Action: ${0}"
}
