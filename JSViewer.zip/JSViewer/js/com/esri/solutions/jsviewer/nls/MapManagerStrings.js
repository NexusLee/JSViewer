/**
 * @author sbiickert
 */
{
	navPanTool: "Pan",
	navZoomInTool: "Zoom In",
	navZoomOutTool: "Zoom Out"
}
