/**
 * @author sbiickert
 */
{
	minimize: "Minimize",
	close: "Close"
}
