/**
 * @author sbiickert
 */
{
	navPanTool: "Move Map",
	navZoomInTool: "Zoom In",
	navZoomOutTool: "Zoom Out"
}
