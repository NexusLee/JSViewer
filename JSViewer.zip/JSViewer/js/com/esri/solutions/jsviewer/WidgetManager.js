define([
    "dojo/_base/declare",
    "dojo/_base/array",
    "dojo/_base/lang",
    "dojo/on",
    "dojo/topic",
    "dijit/_Widget",
    "dijit/_Templated"], function (declare, array, lang, on,topic, _Widget, _Template) {
    return declare([_Widget, _Template], {
        constructor: function () {
            this.widgetDefinitions = {};
            this.widgets = {};
        },

        templateString: "<div style='display: none;'></div>",

        map: null,
        configData: null,

        postMixInProperties: function () {
            //console.log("WidgetManager postMixInProperties");
        },

        postCreate: function () {
            //console.log("WidgetManager postCreate");
            on("configLoadedEvent", this, "onConfig");
            on("mapLoadedEvent", this, "onMapLoad");
            on("menuItemClickedEvent", this, "onMenuClick");
        },

        startup: function () {
            //console.log("WidgetManager startup");
        },

        onConfig: function (configData) {
            //console.log("WidgetManager::onConfig");
            this.configData = configData;

            // Unsubscribe from the event
            var handle = topic.subscribe("configLoadedEvent", onConfig);
            handle.remove();
            //dojo.unsubscribe("configLoadedEvent");

            // Make note of the defined widgets
            // and dojo.require them
            array.forEach(configData.widgets, lang.hitch(this, function (defn) {
                this.widgetDefinitions[defn.label] = defn;
                this.requireWidget(defn.label);
            }));
        },

        onMapLoad: function (map) {
            //console.log("WidgetManager::onMapLoad");
            this.map = map;

            // For testing purposes
            //setTimeout(dojo.hitch(this, function(){
            //	var w = this.getWidget("KML Widget");
            //	dojo.publish("showWidget", [w]);
            //	for (var label in this.widgetDefinitions) {
            //		//console.log("getWidget(" + label + ")");
            //		var w = this.getWidget(label);
            //		dojo.publish("showWidget", [w]);
            //	}
            //}), 1000);
        },

        onMenuClick: function (data) {
            if (data && data.value && data.menuCode && data.menuCode === "widgets.widget") {
                //console.log("onMenuClick for widget '" + data.value + "'");
                try {
                    if (this.widgetDefinitions[data.value]) {
                        var w = this.getWidget(data.value);
                        topic.publish("showWidget", [w]);
                    }
                }
                catch (err) {
                    console.error(err);
                }
            }
        },

        getWidget: function (label) {
            if (!this.widgets[label]) {
                this.loadWidget(label);
            }
            return this.widgets[label];
        },

        requireWidget: function (label) {
            var defn = this.widgetDefinitions[label];
            var reqStr = "dojo." + "require('" + defn.widgetType + "')"; // breaking up dojo. and require necessary to fool the dojo parser!
            eval(reqStr);
        },

        loadWidget: function (label) {
            var defn = this.widgetDefinitions[label];
            var paramStr = "";
            if (defn.config) {
                paramStr = "{ config: '" + defn.config + "'}";
            }

            var loadStr = "var w = new " + defn.widgetType + "(" + paramStr + ")";
            eval(loadStr);

            w.setTitle(defn.label);
            w.setIcon(defn.icon);
            w.setConfig(defn.config);
            w.setMap(this.map);

            this.widgets[label] = w;
        }
    });
});