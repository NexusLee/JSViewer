/**
 * @author sbiickert
 * French Bundle - Done by Eric Gosselin
 */
{
	defaultProjectionName: "Carte (d&eacute;fault)",
	
	panelTitle0: "Entrer URL",
	panelTitle1: "R&eacute;sultats",
	
	promptUrl: "URL GeoRSS",
	
	btnGet: "R&eacute;cup&eacute;rer Fil",
	btnClear: "Effacer",
	
	msgLoad: "Chargement du Fil...",
	msgReady: "Pr&ecirc;t.",
	msgFound: "${0} r&eacute;sultat(s) trouv&eacute;(s)"
}
