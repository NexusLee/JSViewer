/**
 * @author sbiickert
 */
{
	msgLoad: "Loading...",
	msgReady: "Ready.",
	msgFound: "${0} result(s) found."
}
