﻿/**
 * @author sbiickert
 * French Bundle - Done by Eric Gosselin
 */
{
	panelTitle0: "Allumer/éteindre des couches",
	panelTitle1: "Adjuster la transparence",
	
	panelHeading0: "Visibilité des couches",
	panelHeading1: "Transparence des couches"
}
