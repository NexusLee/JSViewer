﻿{
	panelTitle0: "Turn Layers On/Off",
	panelTitle1: "Adjust Transparency",
	
	panelHeading0: "Layer Visibility",
	panelHeading1: "Layer Transparency"
}
